Sys.setlocale(category = "LC_ALL", locale = "Turkish")

library(tidyverse)
library(report)
library(firatheme)
library(ggthemes)
library(readxl)



td <- read_excel("05_04_2021_matches_Genclerbirligi.xlsx")

td <- janitor::clean_names(td)


td1 <- td %>% 
  group_by(hoca) %>% 
  summarise(across(c(2:20), mean, na.rm = TRUE))

td_long <- td1 %>% 
  pivot_longer(cols = 2:20, names_to = "istatistik", values_to = "değer") %>% 
  mutate_if(is.numeric, round, 2)

#gol beklentisi ve gol

gb1 <- td_long %>% 
  filter(istatistik %in% c("x_g_gol_beklentisi", "x_g_donusturme")) %>% 
  ggplot(aes(x= factor(hoca, level = c("Bizati", "Nobre", "Kaplan", "Altıparmak", "Ortalama")), y =değer , 
             fill = istatistik )) +
  geom_col(position=position_dodge2(reverse = TRUE)) +
  geom_text(aes(label = değer), position = position_dodge(width = -1), 
            vjust = -0.5, family = "Fira Sans") +
  geom_vline(xintercept = c(1.5, 4.5), size =1, linetype = 5, color = "darkgrey") +
  scale_fill_manual(labels = c("Gole Dönüştürme", "Gol Beklentisi"), values = c("red", "black"))+
  labs(x="", fill = "Gençlerbirliği") +
  theme_fira() +
  guides(fill = guide_legend(reverse=TRUE)) 


#rakip becerisi

gb2 <- td_long %>% 
  filter(istatistik %in% c("yedigi", "rakip_x_g")) %>% 
  ggplot(aes(x= factor(hoca, level = c("Bizati", "Nobre", "Kaplan", "Altıparmak", "Ortalama")), y =değer , 
             fill = istatistik )) +
  geom_col(position=position_dodge2(reverse = TRUE)) +
  geom_text(aes(label = değer), position = position_dodge(width = -1), 
            vjust = -0.5, family = "Fira Sans") +
  geom_vline(xintercept = c(1.5, 4.5), size =1, linetype = 5, color = "darkgrey") +
  scale_fill_manual(labels = c("Rakip Gol Beklentisi", "Yediği Ortalama"), values = c("red", "black"))+
  labs(x="", fill = "Gençlerbirliği") +
  theme_fira() +
  guides(fill = guide_legend(reverse=TRUE)) 


td_ag <- read_excel("05_04_2021_matches_Ankaragucu.xlsx")

td_ag <- janitor::clean_names(td_ag)


td_ag1 <- td_ag %>% 
  group_by(hoca) %>% 
  summarise(across(c(2:20), mean, na.rm = TRUE))

td_ag_long <- td_ag1 %>% 
  pivot_longer(cols = 2:20, names_to = "istatistik", values_to = "değer") %>% 
  mutate_if(is.numeric, round, 2)

#gol beklentisi ve gol

ag1<- td_ag_long %>% 
  filter(istatistik %in% c("x_g_gol_beklentisi", "x_g_donusturme")) %>% 
  ggplot(aes(x= factor(hoca, level = c("Karaman", "Dalcı", "Çapa",  "Ortalama")), y =değer , 
             fill = istatistik )) +
  geom_col(position=position_dodge2(reverse = TRUE)) +
  geom_text(aes(label = değer), position = position_dodge(width = -1), 
            vjust = -0.5, family = "Fira Sans") +
  geom_vline(xintercept = c(1.5, 3.5), size =1, linetype = 5, color = "darkgrey") +
  scale_fill_manual(labels = c("Gole Dönüştürme", "Gol Beklentisi"), values = c("yellow", "darkblue"))+
  labs(x="", fill = "Ankaragücü") +
  theme_fira() +
  guides(fill = guide_legend(reverse=TRUE)) 



#rakip becerisi

ag2 <- td_ag_long %>% 
  filter(istatistik %in% c("yedigi", "rakip_x_g")) %>% 
  ggplot(aes(x= factor(hoca, level = c("Karaman", "Dalcı", "Çapa",  "Ortalama")), y =değer , 
             fill = istatistik )) +
  geom_col(position=position_dodge2(reverse = TRUE)) +
  geom_text(aes(label = değer), position = position_dodge(width = -1), 
            vjust = -0.5, family = "Fira Sans") +
  geom_vline(xintercept = c(1.5, 3.5), size =1, linetype = 5, color = "darkgrey") +
  scale_fill_manual(labels = c("Rakip Gol Beklentisi", "Yediği Ortalama"), values = c("yellow", "darkblue"))+
  labs(x="", fill = "Ankaragücü") +
  theme_fira() +
  guides(fill = guide_legend(reverse=TRUE)) 


patchwork::wrap_plots(gb1, ag1, gb2, ag2, ncol=2)
