Sys.setlocale(category = "LC_ALL", locale = "Turkish")



library(firatheme)
library(ggthemes)
library(readxl)
library(strengejacke)
library(tidyverse)



kays <- read_excel("C:/Users/emretoros/Downloads/17_04_2021_matches_Kayserispor.xlsx")


kays <- janitor::clean_names(kays)
kays_o <- kays %>%
  filter(x4 != "KAY")


kays_m1 <-
  lm(
    net_x_g_x_g_opponents_x_g  ~  merkezden_hucumlar + 
      sag_kanat_hucumlari + sol_kanat_hucumlari + orta + hava_topu_mucadeleleri +
      korner_hucumlari + high_pressing + kontra_ataklar,
    data = kays_o
  )
tab_model(kays_m1, show.std = T, dv.labels = "Net Gol Beklentisi")


#stepwise regression
kays_m_step <- step(lm(net_x_g_x_g_opponents_x_g  ~  merkezden_hucumlar + sag_kanat_hucumlari + sol_kanat_hucumlari + orta + hava_topu_mucadeleleri +
          korner_hucumlari + high_pressing + kontra_ataklar,
        data= kays_o),direction="both")

kays_m2 <- 
  lm(
    net_x_g_x_g_opponents_x_g  ~  merkezden_hucumlar + sag_kanat_hucumlari + sol_kanat_hucumlari + 
      orta + hava_topu_mucadeleleri + high_pressing,
    data= kays_o
  )
tab_model(kays_m2, show.std = T, dv.labels = "Net Gol Beklentisi")



#update
kays_m3 <-
  lm(
    net_x_g_x_g_opponents_x_g  ~   orta + hava_topu_mucadeleleri +  high_pressing,
    data= kays_o
  )
tab_model(kays_m3, show.std = T, dv.labels = "Net Gol Beklentisi")



# add predicted values to dataset

set_theme(base = theme_clean())

plot_model(kays_m3, type = "pred", 
           axis.title = c("Tahmin Edilen Fazla Gol Beklentisi"),
           title = "Net Gol Beklentisi") 
