library(tidyverse)
library(worldfootballR)
library(firatheme)
#get values of teams

prem_vals <- get_player_market_values(country_name = "Turkey", start_year = 2020)

tr_values <- prem_vals %>% 
  group_by(squad) %>% 
  summarise(mean = mean(player_market_value_euro)) 

q <- get_season_team_stats(country = "TUR", gender = "M", season_end_year = "2021", stat_type = "league_table")

qq <- q %>% 
  select(Squad, Pts)

qq$id <- c("aln", "ag", "ant", "bs", "bjk", "den", "erz", "fth", "fen", "gs", 
           "gaz", "gen", "goz", "hat", "kas", "kay", "kon", "riz", "siv", "tra", "mal")

tr_values$id <- c("aln", "ant", "bjk", "erz", "riz", "den", "fth", "fen", "gs", "gaz", "gen", 
                  "goz", "hat", "bs", "kas", "kay", "kon", "ag", "siv", "tra", "mal" )


deger_puan <- merge(tr_values, qq, by="id")


deger_puan %>% 
  mutate(puan_basi_euro = mean/Pts) %>% 
  ggplot( aes(x = reorder(squad, Pts), y = puan_basi_euro)) + 
  geom_bar(stat = "identity") +
  #geom_text(aes(label=euro_per_point, hjust=-.4), size= 3) +
  coord_flip() +
  labs( x= "", y="Puan başına harcanan Euro", title = "Ne kadar ekmek o kadar köfte.... mi?") +
  ggthemes::theme_clean() +
  theme(text=element_text(family="Times New Roman"))



deger_puan %>% 
  mutate(puan_basi_euro = mean/Pts) %>% 
  ggplot( aes(x = mean, y = Pts)) + 
  geom_point() +
  ggrepel::geom_text_repel(aes(label=squad), size= 3) +
  labs( x= "Takım değeri", y="Puan", title = "Ne kadar ekmek o kadar köfte.... mi?") +
  ggthemes::theme_clean() +
  theme(text=element_text(family="Times New Roman"))
