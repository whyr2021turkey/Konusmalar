library(quantstrat)
Sys.setenv(TZ="UTC")

rm.strat(strategy.name)
rm.strat(portfolio.name)
rm.strat(account.name)
if (!exists('.blotter')) .blotter <- new.env()
if (!exists('.strategy')) .strategy <- new.env()


### FinancialInstrument
currency('TRY')
stock(primary_id = 'TUPRS',currency = "TRY")

### Data

tmp<-OHLC_Data_1min %>% 
  left_join(Predicted_Rets) %>% 
  select(-Ticker) %>% 
  replace_na(list(Predictions=0,CVaR=0))
TUPRS<-xts(as.matrix(tmp[,-1]),tmp$Period) 

initDate = index(TUPRS)[1]

### Blotter
account.name = 'ABC Yatırım'
portfolio.name = 'Hisse'
strategy.name = 'Intraday STrategy'
symbols<-"TUPRS"

initPortf(portfolio.name, symbols=symbols, initDate=initDate, currency='TRY')
initAcct(account.name, portfolios=portfolio.name, initDate=initDate, currency='TRY')
initOrders(portfolio.name, initDate=initDate)

### define strategy
strategy(strategy.name, store=TRUE)

add.signal(strategy.name, name='sigThreshold',
           arguments = list(
             column="Predictions",
             threshold=0.0005,
             relationship="gte"
           ),
           label='long'
)
add.signal(strategy.name, name='sigThreshold',
           arguments = list(
             column="Predictions",
             threshold= -0.0005,
             relationship="lte"
           ),
           label='short'
)


### rules
Order_Sizing_Fnc<-function(timestamp, orderqty, portfolio, symbol, ruletype, ...){
  ClosePrice<-as.numeric(Cl(mktdata[timestamp,]))
  Trade_Size<-1e+08 *
    as.numeric(mktdata[timestamp,"Predictions"])/
    abs(as.numeric(mktdata[timestamp,"CVaR"]))
  Order_Size<-round(Trade_Size/ClosePrice,-1)
  Order_Size<-sign(Order_Size)*min(abs(Order_Size),5000)
  Order_Size
}



add.rule(strategy.name, name='ruleSignal',
         arguments=list(sigcol='long' , 
                        sigval=TRUE,
                        orderside='long' ,
                        ordertype='stoplimit', 
                        prefer='High', 
                        threshold=0.2,
                        orderqty=1,
                        osFUN="Order_Sizing_Fnc",
                        replace=FALSE
         ),
         type='enter',
         label='EnterLONG'
)
add.rule(strategy.name, name='ruleSignal',
         arguments=list(sigcol='short', 
                        sigval=TRUE,
                        orderside='long' ,
                        ordertype='market',
                        orderqty='all',
                        replace=TRUE
         ),
         type='exit',
         label='Exit2SHORT'
)
add.rule(strategy.name, name='ruleSignal',
         arguments=list(sigcol='short', 
                        sigval=TRUE,
                        orderside='short',
                        ordertype='stoplimit', 
                        prefer='Low', 
                        threshold=-0.2,
                        orderqty=-1,
                        osFUN="Order_Sizing_Fnc",
                        replace=FALSE
         ),
         type='enter',
         label='EnterSHORT'
)
add.rule(strategy.name, name='ruleSignal',
         arguments=list(sigcol='long' , 
                        sigval=TRUE,
                        orderside='short',
                        ordertype='market',
                        orderqty='all',
                        replace=TRUE
         ),
         type='exit',
         label='Exit2LONG'
)




###############################################################################
# Apply strategy
applyStrategy(strategy.name, portfolio.name)

# Updates
updatePortf(portfolio.name, Symbols=symbols)
updateAcct(account.name)
updateEndEq(account.name)

###############################################################################
# Analyze indicators, signals, orders, txns
View(mktdata)
View(getOrderBook(portfolio.name)[[portfolio.name]]$TUPRS)
View(t(tradeStats(portfolio.name, 'TUPRS')))
View(perTradeStats(portfolio.name))

# MFE and MAE charts
chart.ME(portfolio.name, 'TUPRS', scale='percent', type='MAE')
chart.ME(portfolio.name, 'TUPRS', scale='percent', type='MFE')

# Analyze portfolio object
myPort <- getPortfolio(portfolio.name)
names(myPort)

names(myPort$symbols)
names(myPort$symbols$TUPRS)
head(myPort$symbols$TUPRS$txn)
head(myPort$symbols$TUPRS$posPL.USD)
head(myPort$symbols$TUPRS$posPL)

names(myPort$summary)

library(lattice)
plot(xyplot(myPort$summary,xlab="",type="h",col=4))

###############################################################################
# Perf chart and equity
chart.Posn(portfolio.name, "TUPRS",Dates=TrainTimes)
chart.Posn(portfolio.name, "TUPRS",Dates=TestTimes)

Eq<-getAccount(account.name)$summary[,"End.Eq"]
plot(as.zoo(window(Eq,TrainTimes)),main="Account Equity",ylab="",xlab="Time",las=1)
plot(as.zoo(window(Eq,TestTimes)),main="Account Equity",ylab="",xlab="Time",las=1)
plot(as.zoo(Eq),main="Account Equity",ylab="",xlab="Time",las=1)
abline(v=tail(TrainTimes,1),col=2,lty=2)

###############################################################################
# save the strategy in an .RData object for later retrieval
save.strategy(strategy.name)




