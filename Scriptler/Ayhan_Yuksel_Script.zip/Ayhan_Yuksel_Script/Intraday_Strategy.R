library(tidyverse)
library(quantstrat)
library(TTR)
library(caret)

#####################################
### DATA      #######################
#####################################
load("Intraday.RData")


#####################################
### FEATURES  #######################
#####################################

# LOB Features
LOB_Data %>% 
  group_by(Period) %>% 
  filter(row_number()==1) %>% 
  summarise(Bid_Ask_Spread=(Satis_F-Alis_F)/((Satis_F+Alis_F)/2)) %>% 
  ggplot(aes(Period,Bid_Ask_Spread))+
  geom_line()


All_LOB_Data<-LOB_Data  %>% 
  nest(LOB=Alis_F:Satis_M)

currentLOB<-All_LOB_Data$LOB[[1]] 

Get_LOB_Features<-function(currentLOB){
  
    BAS<-currentLOB %>% 
      filter(row_number()==1) %>% 
      mutate(Bid_Ask_Spread=(Satis_F-Alis_F)/((Satis_F+Alis_F)/2)) %>% 
      pull(Bid_Ask_Spread)
    
    OI<-currentLOB %>% 
      mutate(Alis_CumVol=cumsum(Alis_M),
             Satis_CumVol=cumsum(Satis_M),
             CumVol_Diff=(Alis_CumVol-Satis_CumVol)/(Alis_CumVol+Satis_CumVol)) %>% 
      pull(CumVol_Diff) %>% 
      (function(x) x[1:10])
    
    out<-c(BAS,OI)
    names(out)<-c("BAS",paste0("OI",1:10))
    bind_rows(out)
}

Get_LOB_Features(currentLOB)

LOB_Features<-All_LOB_Data %>% 
  mutate(Features=map(LOB,Get_LOB_Features)) %>% 
  unnest(Features) %>% 
  select(-LOB)
  

LOB_Features %>% 
  gather(Type,Value,-c(1:2)) %>% 
  ggplot(aes(Period,Value))+
  geom_line()+
  facet_wrap(~Type,scales = "free_y")

# OHLC Features
Get_OHLC_Features<-function(OHLC_Data){
  OHLC_Data %>% 
  mutate(Ret=Close/dplyr::lag(Close,1)-1,
         Forw_Return=dplyr::lead(Ret,2),
         Mom_1=Close/dplyr::lag(Close,1)-1,
         Mom_2=Close/dplyr::lag(Close,2)-1,
         Mom_3=Close/dplyr::lag(Close,3)-1,
         Mom_4=Close/dplyr::lag(Close,4)-1,
         Mom_5=Close/dplyr::lag(Close,5)-1,
         Mom_6=Close/dplyr::lag(Close,6)-1,
         Mom_12=Close/dplyr::lag(Close,12)-1,
         Mom_18=Close/dplyr::lag(Close,18)-1,
         Mom_24=Close/dplyr::lag(Close,24)-1,
         Mom_36=Close/dplyr::lag(Close,36)-1,
         Mom_48=Close/dplyr::lag(Close,48)-1,
         Vol_12=sqrt(EMA(Ret^2,12)),
         Vol_24=sqrt(EMA(Ret^2,24)),
         Vol_480=sqrt(EMA(Ret^2,48)),
         CVaR=rollapply(Ret,48,CVaR,p=0.9,fill=NA,align="r")) %>% 
  select(-Open,-High,-Low,-Close,-Ret)
}

OHLC_Features<-Get_OHLC_Features(OHLC_Data) %>% na.omit
  
  
OHLC_Features %>% 
  gather(Type,Value,-c(1:2)) %>% 
  ggplot(aes(Period,Value))+
  geom_line()+
  facet_wrap(~Type,scales = "free_y")

All_Data<-OHLC_Features %>% 
  left_join(LOB_Features) %>% 
  na.omit

All_Data %>% 
  gather(Feature,Value,-c(1:3)) %>% 
  ggplot(aes(Value,Forw_Return))+
  geom_point()+
  geom_smooth(method = "loess",se=F)+
  facet_wrap(~Feature,scales = "free")

All_Data %>% 
  gather(Feature,Value,-c(1:3)) %>% 
  select(-Ticker,-Period) %>% 
  nest(Forw_Return,Value) %>% 
  mutate(Correl=map_dbl(data,~ cor(.x$Forw_Return,.x$Value))) %>% 
  select(-data) %>% 
  ggplot(aes(Feature,Correl))+
  geom_col()+ 
  coord_flip()


#####################################
### PREDICTION      #################
#####################################


# a) Prediction: 6 period momentum

Predicted_Rets<-tibble(Period=All_Data$Period,
                       CVaR= -All_Data$CVaR) %>% 
  left_join(OHLC_Features %>%  select(Period,Predictions=Mom_6/6))



# b) Prediction: Machine learning based

Traindat<-All_Data[1:1000,-c(1:3)]
TrainResponse<-unlist(All_Data[1:1000,3])
TrainTimes<-All_Data$Period[1:1000]

Testdat<-All_Data[-c(1:1000),-c(1:3)]
TestResponse<-unlist(All_Data[-c(1:1000),3])
TestTimes<-All_Data$Period[-c(1:1000)]

TS.CV.Control <- trainControl(method = "timeslice",
                              initialWindow = round(nrow(Traindat)/2),
                              horizon = 6,
                              skip = round(nrow(Traindat)/6)-1,
                              fixedWindow = T,
                              allowParallel = F,
                              returnResamp = "none",
                              savePredictions = "all")

set.seed(888)
fit <- train(x = Traindat ,
             y = TrainResponse,
             method = "ranger",
             trControl = TS.CV.Control,
             tuneGrid = expand.grid(
               mtry=c(4,6,8,10),
               splitrule="variance",
               min.node.size=c(2:4)),
             metric="RMSE")

Predicted_Rets_IS<-predict(fit,newdata = Traindat)
Predicted_Rets_OOS<-predict(fit,newdata = Testdat)
Predicted_Rets<-tibble(Period=All_Data$Period,
                       Predictions=c(Predicted_Rets_IS,Predicted_Rets_OOS),
                       CVaR= -All_Data$CVaR)





